from django.apps import AppConfig


class JogadoresConfig(AppConfig):
    name = 'desenvolvedores'
